from flask import Flask, request, abort
import subprocess
import os
import random
app = Flask(__name__)

@app.route('/')
def index():
    return "Neon Flex Internal Debug Service. /flag - to Check the current flag. /ping - to check if the service is up."

@app.route('/ping')
def ping():
    return "pong"

# intentionally vulnerable endpoint (CTF use only)
@app.route('/flag')
def run():
    # get a random number
    random_number = random.randint(1, 1000)
    if (random_number < 100):
        return "Your Luck is Bad. No Flag for you....."
    # check if flag file exists
    if not os.path.exists('/flag.txt'):
        abort(404)

    # read flag file
    with open('/flag.txt', 'r') as f:
        flag = f.read()

    return flag


