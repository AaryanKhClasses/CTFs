"use client";

import VideoPlayer from "./VideoPlayer";

interface VideoCardProps {
	title: string;
	thumbnail: string;
	videoUrl?: string;
	views: string;
	likes: string;
	duration: string;
	isLocked?: boolean;
}

export default function VideoCard({
	title,
	thumbnail,
	videoUrl,
	views,
	likes,
	isLocked = false
}: VideoCardProps) {
	return (
		<div className="bg-white rounded-lg shadow-lg overflow-hidden">
			<VideoPlayer
				videoUrl={videoUrl}
				title={title}
				thumbnail={thumbnail}
				isLocked={isLocked}
			/>

			<div className="p-4">
				<h3 title={title} className="font-semibold text-gray-800 mb-2 line-clamp-2">
					{title}
				</h3>
				<div className="flex items-center text-sm text-gray-600">
					<span>{views} views</span>
					<span className="mx-2">•</span>
					<span>{likes} likes</span>
				</div>
			</div>
		</div>
	);
}