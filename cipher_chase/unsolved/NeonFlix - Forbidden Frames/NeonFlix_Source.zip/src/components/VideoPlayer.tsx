"use client";

import { useState, useRef } from "react";

interface VideoPlayerProps {
	videoUrl?: string;
	title: string;
	thumbnail: string;
	isLocked: boolean;
}

export default function VideoPlayer({ videoUrl, thumbnail, isLocked }: VideoPlayerProps) {
	const [isPlaying, setIsPlaying] = useState(false);
	const videoRef = useRef<HTMLVideoElement>(null);

	if (isLocked) {
		return (
			<div className="relative h-64 bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center rounded-lg">
				<span className="text-6xl">{thumbnail}</span>
				<div className="absolute inset-0 bg-black bg-opacity-60 flex items-center justify-center rounded-lg">
					<div className="text-center">
						<span className="text-white text-4xl">🔒</span>
						<p className="text-white mt-2">Sign in to watch</p>
					</div>
				</div>
			</div>
		);
	}

	// If no video URL, show placeholder
	if (!videoUrl) {
		return (
			<div className="relative h-64 bg-gradient-to-br from-purple-400 to-pink-400 flex items-center justify-center rounded-lg cursor-pointer group"
				onClick={() => setIsPlaying(!isPlaying)}>
				<span className="text-6xl">{thumbnail}</span>
				<div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all flex items-center justify-center rounded-lg">
					<span className="text-white text-4xl opacity-0 group-hover:opacity-100 transition-opacity">▶️</span>
				</div>
			</div>
		);
	}

	// Show actual video player
	return (
		<div className="relative bg-black rounded-lg overflow-hidden">
			<video
				ref={videoRef}
				className="w-full h-64 object-cover"
				controls
			>
				<source src={videoUrl} type="video/mp4" />
				Your browser does not support the video tag.
			</video>
		</div>
	);
}