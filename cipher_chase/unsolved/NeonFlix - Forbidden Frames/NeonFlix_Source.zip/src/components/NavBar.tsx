"use client";

import { useSession, signOut } from "next-auth/react";
import Link from "next/link";
import { useState, useEffect } from "react";

export default function Navbar() {
	const { data: session, status } = useSession();
	const [isLoading, setIsLoading] = useState(false);
	const [currentTime, setCurrentTime] = useState("");
	const [connectionStatus, setConnectionStatus] = useState("SECURE");

	useEffect(() => {
		// Update time display
		const updateTime = () => {
			const now = new Date();
			const timeString = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`;
			setCurrentTime(timeString);
		};

		updateTime();
		const timeInterval = setInterval(updateTime, 1000);

		// Simulate connection status changes
		const statusOptions = ["SECURE", "ENCRYPTED", "ANONYMOUS", "PROTECTED"];
		const statusInterval = setInterval(() => {
			setConnectionStatus(statusOptions[Math.floor(Math.random() * statusOptions.length)]);
		}, 5000);

		return () => {
			clearInterval(timeInterval);
			clearInterval(statusInterval);
		};
	}, []);

	const handleSignOut = async () => {
		setIsLoading(true);
		await signOut({ callbackUrl: '/challenge' });
		setIsLoading(false);
	};

	return (
		<nav className="bg-gradient-to-r from-black via-gray-900 to-black border-b border-green-400/30 shadow-lg relative overflow-hidden font-mono">
			{/* Background effects */}
			<div className="absolute inset-0 bg-green-400/5"></div>
			<div className="absolute inset-0 opacity-10">
				<div className="grid grid-cols-20 h-full">
					{[...Array(20)].map((_, i) => (
						<div key={i} className="border-r border-green-400/20"></div>
					))}
				</div>
			</div>

			<div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
				<div className="flex justify-between items-center h-16">
					{/* Logo and Status */}
					<div className="flex items-center space-x-6">
						<Link href="/" className="flex items-center space-x-3">
							<div className="text-3xl animate-pulse">🔥</div>
							<div className="flex flex-col">
								<span className="text-green-400 text-xl font-bold tracking-wider glitch-text">
									NEONFLIX
								</span>
								<span className="text-xs text-cyan-400">UNDERGROUND.NET</span>
							</div>
						</Link>
						
						{/* Connection Status */}
						<div className="hidden md:flex items-center space-x-2 text-xs">
							<div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
							<span className="text-green-400">[{connectionStatus}]</span>
						</div>
					</div>

					{/* Center Status Bar */}
					<div className="hidden lg:flex items-center space-x-4 text-xs text-cyan-400">
						<span>TIME: {currentTime}</span>
						<span>•</span>
						<span>NET: 3025.CE</span>
						<span>•</span>
						<span className="text-yellow-400 animate-pulse">FIREWALL: BYPASSED</span>
					</div>

					{/* User Controls */}
					<div className="flex items-center space-x-4">
						{status === "loading" ? (
							<div className="flex items-center space-x-2">
								<div className="w-2 h-2 bg-yellow-400 animate-pulse rounded-full"></div>
								<span className="text-yellow-400 text-sm">AUTHENTICATING...</span>
							</div>
						) : session ? (
							<>
								<div className="flex items-center space-x-3">
									<div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
									<div className="text-sm">
										<span className="text-green-400">[USER:]</span>
										<span className="text-cyan-400 ml-1 font-semibold">
											{session.user?.name || session.user?.email}
										</span>
									</div>
								</div>
								<button
									onClick={handleSignOut}
									disabled={isLoading}
									className="bg-gradient-to-r from-red-900 to-red-700 hover:from-red-700 hover:to-red-500 text-red-300 px-4 py-2 text-sm font-bold transition-all duration-300 disabled:opacity-50 border border-red-400/50 hover:border-red-400 hover:shadow-lg hover:shadow-red-400/30"
								>
									{isLoading ? "[DISCONNECTING...]" : "[DISCONNECT]"}
								</button>
							</>
						) : (
							<>
								<Link
									href="/auth/signin"
									className="text-green-400 hover:text-green-300 transition-colors text-sm hover:shadow-lg hover:shadow-green-400/20 px-2 py-1"
								>
									[LOGIN]
								</Link>
								<Link
									href="/auth/signup"
									className="bg-gradient-to-r from-purple-900 to-pink-900 hover:from-purple-700 hover:to-pink-700 text-purple-300 px-4 py-2 text-sm font-bold transition-all duration-300 border border-purple-400/50 hover:border-purple-400 hover:shadow-lg hover:shadow-purple-400/30"
								>
									[JOIN.NET]
								</Link>
							</>
						)}
					</div>
				</div>

				{/* Bottom Status Bar */}
				<div className="hidden sm:flex justify-between items-center py-1 text-xs border-t border-green-400/20 bg-black/20">
					<div className="flex items-center space-x-4 text-gray-400">
						<span>PROTOCOL: HTTPS/3.0</span>
						<span>•</span>
						<span>PROXY: ACTIVE</span>
						<span>•</span>
						<span>TRACE: DISABLED</span>
					</div>
					<div className="flex items-center space-x-2">
						<span className="text-red-400 animate-pulse">⚠ CORP.MONITOR.DETECTED</span>
					</div>
				</div>
			</div>

			{/* Glitch effect overlay */}
			<div className="absolute inset-0 pointer-events-none">
				<div className="w-full h-full bg-gradient-to-r from-transparent via-cyan-400/5 to-transparent opacity-50 animate-pulse"></div>
			</div>

			<style jsx>{`
				.glitch-text {
					animation: glitch 3s infinite;
				}

				@keyframes glitch {
					0%, 90%, 100% {
						transform: translate(0);
					}
					20% {
						transform: translate(-1px, 1px);
					}
					40% {
						transform: translate(-1px, -1px);
					}
					60% {
						transform: translate(1px, 1px);
					}
					80% {
						transform: translate(1px, -1px);
					}
				}
			`}</style>
		</nav>
	);
}