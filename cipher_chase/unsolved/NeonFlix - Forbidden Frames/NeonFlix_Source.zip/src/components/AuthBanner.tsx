"use client";

import Link from "next/link";
import { useState, useEffect } from "react";

export default function AuthBanner() {
	const [glitchText, setGlitchText] = useState("ACCESS DENIED");
	const [isGlitching, setIsGlitching] = useState(false);

	useEffect(() => {
		const glitchSequence = ["ACCESS DENIED", "ÀĆĆË$$ ÐËÑÏËÐ", "4CC355 D3N13D", "ACCESS DENIED"];
		let currentIndex = 0;

		const glitchInterval = setInterval(() => {
			setIsGlitching(true);
			setTimeout(() => {
				currentIndex = (currentIndex + 1) % glitchSequence.length;
				setGlitchText(glitchSequence[currentIndex]);
				setIsGlitching(false);
			}, 100);
		}, 3000);

		return () => clearInterval(glitchInterval);
	}, []);

	return (
		<div className="relative mb-8 font-mono">
			{/* Background grid effect */}
			<div className="absolute inset-0 bg-gradient-to-r from-red-900/20 via-black to-red-900/20 border border-red-400/50"></div>
			<div className="absolute inset-0 opacity-20">
				<div className="grid grid-cols-8 grid-rows-4 h-full w-full">
					{[...Array(32)].map((_, i) => (
						<div key={i} className="border border-red-400/30 animate-pulse"></div>
					))}
				</div>
			</div>

			{/* Main content */}
			<div className="relative z-10 p-6">
				<div className="flex items-center justify-between">
					<div className="flex items-center space-x-4">
						<div className="text-6xl animate-pulse">🚫</div>
						<div>
							<h2 className={`text-3xl font-bold mb-2 ${isGlitching ? 'animate-pulse text-red-300' : 'text-red-400'}`}>
								{glitchText}
							</h2>
							<p className="text-green-300 mb-2">
								[UNAUTHORIZED USER DETECTED]
							</p>
							<p className="text-cyan-400 text-sm">
								INITIATE SECURITY CLEARANCE TO ACCESS FORBIDDEN STREAMS
							</p>
							<div className="text-yellow-400 text-xs mt-2 animate-pulse">
								► CORPORATE FIREWALL BYPASSED • ENTER CREDENTIALS ◄
							</div>
						</div>
					</div>
					<div className="flex flex-col space-y-3">
						<Link
							href="/auth/signin"
							className="bg-gradient-to-r from-green-900 to-green-700 text-green-300 px-6 py-3 font-bold hover:from-green-700 hover:to-green-500 transition-all duration-300 border border-green-400/50 hover:border-green-400 hover:shadow-lg hover:shadow-green-400/30"
						>
							[AUTHENTICATE]
						</Link>
						<Link
							href="/auth/signup"
							className="bg-gradient-to-r from-purple-900 to-pink-900 text-purple-300 px-6 py-3 font-bold hover:from-purple-700 hover:to-pink-700 transition-all duration-300 border border-purple-400/50 hover:border-purple-400 hover:shadow-lg hover:shadow-purple-400/30"
						>
							[JOIN NETWORK]
						</Link>
					</div>
				</div>

				{/* Warning ticker */}
				<div className="mt-4 bg-black/50 border-t border-red-400/30 pt-3">
					<div className="text-red-400 text-xs animate-pulse">
						⚠ WARNING: Unauthorized access attempts are being logged and reported to Network Security ⚠
					</div>
				</div>
			</div>

			{/* Glitch overlay effect */}
			<div className={`absolute inset-0 bg-red-400/10 pointer-events-none transition-opacity duration-100 ${isGlitching ? 'opacity-100' : 'opacity-0'}`}>
				<div className="w-full h-full bg-gradient-to-r from-transparent via-red-400/20 to-transparent"></div>
			</div>
		</div>
	);
}