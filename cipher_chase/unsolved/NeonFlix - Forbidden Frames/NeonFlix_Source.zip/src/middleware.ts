import { getToken } from 'next-auth/jwt';
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { v4 } from 'uuid';

export async function middleware(request: NextRequest) {
	const { pathname, searchParams } = request.nextUrl;
	const token = await getToken({ req: request, secret: process.env.NEXTAUTH_SECRET });

	if (!token && pathname === '/' && (
		searchParams.has('utm_source') ||
		searchParams.has('utm_medium') ||
		searchParams.has('utm_campaign')
	)) {
		const requestHeaders = new Headers(request.headers);
		const res = {
			headers: requestHeaders,
			request: {
				headers: requestHeaders,
			}
		};

		// TODO: Handle analytics

		return NextResponse.next(res);
	};

	// Add security headers
	const response = NextResponse.next();
	const nonce = Buffer.from(v4()).toString('base64');
	const CSPHeader: string = `
		default-src 'self';
		script-src 'self' 'unsafe-eval' 'nonce-${nonce}' http://localhost https://ctf.iiitb.net blob:;
		connect-src 'self' http://localhost https://ctf.iiitb.net;
		style-src 'self' 'unsafe-inline' http://localhost https://ctf.iiitb.net;
		img-src 'self' blob: data: http://localhost https://ctf.iiitb.net;
		font-src https://fonts.googleapis.com/ https://fonts.gstatic.com/ http://localhost https://ctf.iiitb.net;
		object-src 'none';
		base-uri 'self';
		form-action 'self' http://localhost https://ctf.iiitb.net;
		frame-ancestors 'self';
		block-all-mixed-content;
		upgrade-insecure-requests;
		frame-src http://localhost https://ctf.iiitb.net blob:
	`;

	response.headers.set('x-nonce', `${nonce}`);
	response.headers.set('Content-Security-Policy', CSPHeader.replace(/\s{2,}/g, ' ').trim());
	response.headers.set('Referrer-Policy', 'no-referrer');
	response.headers.set('X-Frame-Options', 'SAMEORIGIN');
	response.headers.set('X-Content-Type-Options', 'nosniff');
	response.headers.set('X-Current-Path', `${request?.nextUrl?.pathname ?? 'Unknown'}`);

	return response;
};

export const config = {
	matcher: [
		/*
		* Middleware must match all request paths except for the ones starting with:
		* - api (API routes)
		* - _next/static (static files)
		* - _next/image (image optimization files)
		* - favicon.ico (favicon file)
		*/
		{
			source: '\/((?!api|\_next\/static|\_next\/image|favicon\.ico).*)',
			missing: [
				{ type: 'header', key: 'next-router-prefetch' },
				{ type: 'header', key: 'purpose', value: 'prefetch' },
			],
		},
	],
};