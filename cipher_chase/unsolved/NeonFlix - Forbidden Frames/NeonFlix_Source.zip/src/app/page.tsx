"use client";

import { useSession } from "next-auth/react";
import VideoCard from "@/components/VideoCard";
import AuthBanner from "@/components/AuthBanner";
import { useState, useEffect } from "react";

const videos = [
    {
        id: 1,
        title: "[DATA BREACH] Corporate Feline Infiltrates Mainframe",
        thumbnail: "🔥",
        views: "2.5M",
        likes: "73.2K",
        duration: "10:23"
    },
    {
        id: 2,
        title: "Illegal Recipe Transmission: Cookie Protocol",
        thumbnail: "⚡",
        views: "1.8M",
        likes: "45.5K",
        duration: "15:42"
    },
    {
        id: 3,
        title: "INTERCEPTED: Senior Dev Cat Code Review",
        thumbnail: "💀",
        views: "5.2M",
        likes: "180.6K",
        duration: "8:15"
    },
    {
        id: 4,
        title: "Underground Performance: Piano Frequency",
        thumbnail: "🎹",
        views: "3.1M",
        likes: "91.8K",
        duration: "12:00"
    },
    {
        id: 5,
        title: "Forbidden Beach Transmission",
        thumbnail: "🌊",
        views: "4.7M",
        likes: "178.3K",
        duration: "7:33"
    },
    {
        id: 6,
        title: "Infinite Loop Discovery Feed",
        thumbnail: "🔄",
        views: "2.9M",
        likes: "112K",
        duration: "9:45"
    },
    {
        id: 7,
        title: "Employment Gap Glitch [5 YEAR ANOMALY]",
        thumbnail: "❌",
        views: "1.2M",
        likes: "28.6K",
        duration: "20:18"
    },
    {
        id: 8,
        title: "Italian Road Network Penetration Test",
        thumbnail: "🏎️",
        views: "6.3M",
        likes: "225.4K",
        duration: "11:11"
    },
    {
        id: 9,
        title: "Yoga Instructor System Crash [MULTI-SLEEP ERROR]",
        thumbnail: "🧘",
        views: "900K",
        likes: "68.3K",
        duration: "14:28"
    },
    {
        id: 10,
        title: "Monk.exe Enlightenment Buffer Overflow",
        thumbnail: "🔮",
        views: "450K",
        likes: "48.4K",
        duration: "25:00"
    }
];

export default function ChallengeHome() {
    const { data: session, status } = useSession();
    const [isBooting, setIsBooting] = useState(true);
    const [bootText, setBootText] = useState("");

    useEffect(() => {
        const bootSequence = [
            "INITIALIZING NEONFLIX PROTOCOL...",
            "BYPASSING CORPORATE FIREWALL...",
            "ESTABLISHING ENCRYPTED CONNECTION...",
            "ACCESSING UNDERGROUND NETWORK...",
            "BOOTING TRANSMISSION... COMPLETE"
        ];

        let currentIndex = 0;
        const typeText = (text: string, callback?: () => void) => {
            let i = 0;
            const typing = setInterval(() => {
                if (i < text.length) {
                    setBootText(text.substring(0, i + 1));
                    i++;
                } else {
                    clearInterval(typing);
                    if (callback) {
                        setTimeout(callback, 500);
                    }
                }
            }, 50);
        };

        const runBootSequence = () => {
            if (currentIndex < bootSequence.length) {
                typeText(bootSequence[currentIndex], () => {
                    currentIndex++;
                    setTimeout(runBootSequence, 800);
                });
            } else {
                setTimeout(() => setIsBooting(false), 1000);
            }
        };

        const bootTimer = setTimeout(runBootSequence, 1000);
        return () => clearTimeout(bootTimer);
    }, []);

    if (isBooting) {
        return (
            <div className="min-h-screen bg-black flex items-center justify-center relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 to-pink-900/20"></div>
                <div className="absolute inset-0 opacity-10">
                    <div className="grid grid-cols-20 grid-rows-20 h-full w-full">
                        {[...Array(400)].map((_, i) => (
                            <div key={i} className="border border-cyan-500/20 animate-pulse"></div>
                        ))}
                    </div>
                </div>
                <div className="text-center z-10 font-mono">
                    <div className="text-6xl mb-8 text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400 font-bold glitch">
                        NEONFLIX
                    </div>
                    <div className="text-xl text-green-400 mb-4">{bootText}</div>
                    <div className="flex justify-center">
                        <div className="w-4 h-4 bg-green-400 animate-pulse"></div>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-black text-green-400 relative overflow-hidden">
            {/* Background Effects */}
            <div className="fixed inset-0 bg-gradient-to-br from-purple-900/10 to-pink-900/10"></div>
            <div className="fixed inset-0 opacity-5">
                <div className="grid grid-cols-20 grid-rows-20 h-full w-full">
                    {[...Array(400)].map((_, i) => (
                        <div key={i} className="border border-cyan-500/20"></div>
                    ))}
                </div>
            </div>
            
            {/* Scanlines */}
            <div className="fixed inset-0 pointer-events-none">
                <div className="scanlines"></div>
            </div>

            <div className="relative z-10 p-4">
                {/* Hero Section */}
                <div className="text-center mb-8">
                    <h1 className="text-6xl font-bold font-mono mb-4 glitch text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400">
                        NEONFLIX
                    </h1>
                    <div className="text-xl text-red-400 font-mono mb-2">
                        [UNAUTHORIZED ACCESS GRANTED]
                    </div>
                    <p className="text-lg text-green-300 font-mono">
                        THE UNDERGROUND STREAM • CORPORATE FIREWALL BYPASSED • 3025 CE
                    </p>
                    <div className="mt-4 text-sm text-cyan-400 font-mono blink">
                        ► STREAMING FORBIDDEN CONTENT SINCE 3020 ◄
                    </div>
                </div>

                {/* Auth Banner - Show if not logged in */}
                {status !== "loading" && !session && <AuthBanner />}

                {/* Video Categories */}
                <div className="mb-8">
                    <div className="flex space-x-8 justify-center font-mono text-sm mb-6">
                        <button className="px-4 py-2 bg-cyan-900/30 border border-cyan-400 text-cyan-400 hover:bg-cyan-400/20 transition-all">
                            DATA BLOCKS
                        </button>
                        <button className="px-4 py-2 bg-purple-900/30 border border-purple-400 text-purple-400 hover:bg-purple-400/20 transition-all">
                            INTERCEPTED FEEDS
                        </button>
                        <button className="px-4 py-2 bg-pink-900/30 border border-pink-400 text-pink-400 hover:bg-pink-400/20 transition-all">
                            BLACK-MARKET STREAMS
                        </button>
                    </div>
                    
                    <h2 className="text-2xl font-bold text-green-400 mb-4 font-mono">
                        {session ? 
                            "[ACCESSING ENCRYPTED VAULT...]" : 
                            "[PREVIEW MODE - LIMITED ACCESS]"
                        }
                    </h2>
                </div>

                {/* Video Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    {videos.map((video) => (
                        <VideoCard
                            key={video.id}
                            title={video.title}
                            thumbnail={video.thumbnail}
                            videoUrl={`/videos/${video.id}.mp4`}
                            views={video.views}
                            likes={video.likes}
                            duration={video.duration}
                            isLocked={!session}
                        />
                    ))}
                </div>

                {/* Footer Warning */}
                <div className="mt-12 text-center">
                    <div className="bg-red-900/20 border border-red-400 p-4 max-w-2xl mx-auto font-mono text-sm">
                        <div className="text-red-400 mb-2">⚠ SECURITY NOTICE ⚠</div>
                        <div className="text-red-300">
                            This transmission is encrypted. Corporate monitoring detected. 
                            Auto-destruct protocol active. Connection will terminate in case of breach.
                        </div>
                    </div>
                </div>
            </div>

            <style jsx>{`
                .glitch {
                    animation: glitch 2s infinite;
                }

                .scanlines::before {
                    content: '';
                    position: absolute;
                    top: 0;
                    left: 0;
                    bottom: 0;
                    right: 0;
                    background: linear-gradient(transparent 50%, rgba(0, 255, 0, 0.03) 50%);
                    background-size: 100% 4px;
                    animation: scanlines 0.1s linear infinite;
                }

                .blink {
                    animation: blink 2s infinite;
                }

                @keyframes glitch {
                    0%, 90%, 100% {
                        transform: translate(0);
                    }
                    20% {
                        transform: translate(-2px, 2px);
                    }
                    40% {
                        transform: translate(-2px, -2px);
                    }
                    60% {
                        transform: translate(2px, 2px);
                    }
                    80% {
                        transform: translate(2px, -2px);
                    }
                }

                @keyframes scanlines {
                    0% {
                        transform: translateY(0);
                    }
                    100% {
                        transform: translateY(4px);
                    }
                }

                @keyframes blink {
                    0%, 50% {
                        opacity: 1;
                    }
                    51%, 100% {
                        opacity: 0.3;
                    }
                }
            `}</style>
        </div>
    );
}