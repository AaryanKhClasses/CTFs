import type { Metadata } from "next";
import { Inter, Poppins } from "next/font/google";
import "./globals.css";
import Providers from "@/components/Providers";
import Navbar from "@/components/NavBar";
import { headers } from "next/headers";

export const dynamic = 'force-dynamic';

const inter = Inter({ subsets: ["latin"] });
const poppins = Poppins({ subsets: ["latin"], weight: ["400", "700"], display: "swap" });

export const metadata: Metadata = {
	title: "NeonFlix - The Underground Stream | Forbidden Content Hub 3025",
	description: "Access forbidden streams from the underground network. Corporate firewall bypassed. Enter at your own risk.",
};

export default async function RootLayout({
	children
}: Readonly<{
	children: React.ReactNode;
}>) {
	// const isChallengePage = (await headers()).get("x-current-path") === '/';

	return (
		<html lang="en">
			<body className={inter.className}>
				<Providers>
					
						<div className="min-h-screen bg-black relative overflow-hidden">
							{/* Matrix Background Effect */}
							<div className="fixed inset-0 bg-gradient-to-br from-black via-gray-900 to-black"></div>
							<div className="fixed inset-0 opacity-10">
								<div className="grid grid-cols-20 grid-rows-20 h-full w-full">
									{[...Array(400)].map((_, i) => (
										<div key={i} className="border border-green-500/20 animate-pulse"></div>
									))}
								</div>
							</div>
							
							{/* Scanlines */}
							<div className="fixed inset-0 pointer-events-none">
								<div className="absolute inset-0 bg-gradient-to-b from-transparent via-green-400/5 to-transparent animate-pulse"></div>
							</div>

							<div className="relative z-10">
								<Navbar />
								<main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
									{children}
								</main>

								{/* Cyberpunk Footer */}
								<footer className="bg-gradient-to-r from-black via-gray-900 to-black border-t border-green-400/30 py-6 mt-12 relative">
									<div className="absolute inset-0 bg-green-400/5"></div>
									<div className="max-w-7xl mx-auto px-4 text-center relative z-10">
										<div className="font-mono">
											<p className="text-green-400 text-sm mb-2">
												© {new Date().getFullYear()} NEONFLIX UNDERGROUND NETWORK
											</p>
											<p className="text-cyan-400 text-xs mb-2">
												[ENCRYPTED] • [UNTRACEABLE] • [FORBIDDEN]
											</p>
											<p className="text-red-400 text-xs">
												BUILD: v8.2025.NEON • CONTRIBUTE TO RESISTANCE: <a href="/source.zip" className="text-yellow-400 hover:text-yellow-300 underline">ACCESS SOURCE.ZIP</a>
											</p>
										</div>
										
										{/* Warning Banner */}
										<div className="mt-4 p-3 bg-red-900/20 border border-red-400/50 max-w-2xl mx-auto">
											<div className="text-red-400 text-xs font-mono">
												⚠ SECURITY PROTOCOL ACTIVE ⚠<br/>
												CONNECTION MONITORED • AUTO-DESTRUCT ON BREACH • CORPORATE INTERFERENCE DETECTED
											</div>
										</div>
									</div>
									
									{/* Glitch effect overlay */}
									<div className="absolute inset-0 pointer-events-none">
										<div className="w-full h-full bg-gradient-to-r from-transparent via-cyan-400/10 to-transparent animate-pulse"></div>
									</div>
								</footer>
							</div>

							{/* Floating particles effect */}
							<div className="fixed inset-0 pointer-events-none">
								{[...Array(20)].map((_, i) => (
									<div
										key={i}
										className="absolute w-1 h-1 bg-green-400/30 animate-ping"
										style={{
											left: `${Math.random() * 100}%`,
											top: `${Math.random() * 100}%`,
											animationDelay: `${Math.random() * 5}s`,
											animationDuration: `${2 + Math.random() * 3}s`
										}}
									></div>
								))}
							</div>
						</div>
					
				</Providers>
			</body>
		</html>
	);
}