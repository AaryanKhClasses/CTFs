"use client";

import { signIn } from "next-auth/react";
import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function SignUp() {
	const router = useRouter();
	const [formData, setFormData] = useState({
		name: "",
		email: "",
		password: "",
		confirmPassword: "",
	});
	const [error, setError] = useState("");
	const [isLoading, setIsLoading] = useState(false);

	const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
		setFormData({
			...formData,
			[e.target.name]: e.target.value,
		});
	};

	const handleSubmit = async (e: React.FormEvent) => {
		e.preventDefault();
		setError("");

		// Validate passwords match
		if (formData.password !== formData.confirmPassword) {
			setError("Passwords do not match");
			return;
		}

		// Validate password length
		if (formData.password.length < 6) {
			setError("Password must be at least 6 characters");
			return;
		}

		setIsLoading(true);

		try {
			// Register the user
			const res = await fetch("/api/auth/register", {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
				},
				body: JSON.stringify({
					name: formData.name,
					email: formData.email,
					password: formData.password,
				}),
			});

			const data = await res.json();

			if (!res.ok) {
				setError(data.error || "Failed to create account");
				return;
			}

			// Auto sign in after successful registration
			const result = await signIn("credentials", {
				email: formData.email,
				password: formData.password,
				redirect: false,
			});

			if (result?.error) {
				setError("Account created but failed to sign in. Please try signing in manually.");
			} else {
				router.push("/challenge");
				router.refresh();
			}
		} catch {
			setError("An error occurred. Please try again.");
		} finally {
			setIsLoading(false);
		}
	};

	return (
		<div className="min-h-[calc(100vh-200px)] flex items-center justify-center">
			<div className="p-8 rounded-2xl shadow-2xl w-full max-w-md">
				<div className="text-center mb-8">
					<h2 className="text-3xl font-bold mt-4">Register</h2>
				</div>

				<form onSubmit={handleSubmit} className="space-y-4">
					<div>
						<label htmlFor="name" className="block text-sm font-medium  mb-2">
							Full Name
						</label>
						<input
							type="text"
							id="name"
							name="name"
							value={formData.name}
							onChange={handleChange}
							required
							className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none transition"
							placeholder="Anonymous"
						/>
					</div>

					<div>
						<label htmlFor="email" className="block text-sm font-medium  mb-2">
							Email Address
						</label>
						<input
							type="email"
							id="email"
							name="email"
							value={formData.email}
							onChange={handleChange}
							required
							className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none transition"
							placeholder="resistance@example.com"
						/>
					</div>

					<div>
						<label htmlFor="password" className="block text-sm font-medium  mb-2">
							Password
						</label>
						<input
							type="password"
							id="password"
							name="password"
							value={formData.password}
							onChange={handleChange}
							required
							className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none transition"
							placeholder="••••••••"
						/>
					</div>

					<div>
						<label htmlFor="confirmPassword" className="block text-sm font-medium  mb-2">
							Confirm Password
						</label>
						<input
							type="password"
							id="confirmPassword"
							name="confirmPassword"
							value={formData.confirmPassword}
							onChange={handleChange}
							required
							className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none transition"
							placeholder="••••••••"
						/>
					</div>

					{error && (
						<div className="bg-red-50 text-red-600 p-3 rounded-lg text-sm">
							{error}
						</div>
					)}

					<button
						type="submit"
						disabled={isLoading}
						className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white py-3 rounded-lg font-semibold hover:from-purple-700 hover:to-pink-700 transition-all disabled:opacity-50"
					>
						{isLoading ? "Creating account..." : "Sign Up"}
					</button>
				</form>

				<div className="mt-6 text-center">
					<p className="text-gray-600">
						Already have an account?{" "}
						<Link href="/auth/signin" className="text-purple-600 hover:text-purple-700 font-semibold">
							Sign in
						</Link>
					</p>
				</div>

				{/* Terms and CTF hint */}
				<div className="mt-8 pt-6 border-t border-gray-200">
					<p className="text-xs text-gray-400 text-center">
						By signing up, you agree to our Terms of Service and Privacy Policy.
						<br />
						<span className="text-gray-300">
							{/* Hint for CTF players */}
							{/* Internal services use default configurations */}
						</span>
					</p>
				</div>
			</div>
		</div>
	);
}