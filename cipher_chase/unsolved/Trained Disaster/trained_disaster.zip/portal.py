#!/usr/bin/env python3
import sys
import csv
import math
import hashlib
import time
import textwrap
import random
# ------------------------
# EMBEDDED (author-run values)
# ------------------------
SALT_HEX = 'a393672a99331bc36caa541291f47bdf'
EMBED_DIGEST = '8419f7e4dcf2fdc3dfe58c03a48a65b28b6b6b8c14fe0155f582cdf7b68ce35d'
# ------------------------

EXPECTED_LENGTH = 16

# ---------- ASCII Art & UI ----------
BANNER = r""" 
 ____ ___      .__      __________              __         .__   
|    |   \____ |__|__  _\______   \____________/  |______  |  |  
|    |   /    \|  \  \/ /|     ___/  _ \_  __ \   __\__  \ |  |  
|    |  /   |  \  |\   / |    |  (  <_> )  | \/|  |  / __ \|  |__
|______/|___|  /__| \_/  |____|   \____/|__|   |__| (____  /____/
             \/                                          \/      
"""

HEALTH_ART = r"""
   _   _      _   _   _   _   _   _   _   _
  / \ / \    / \ / \ / \ / \ / \ / \ / \ / \
 ( H | E )  ( A | L | T | H |   | P | O | R )
  \_/ \_/    \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/
"""

NONCRIT_ART = r"""
  _____  O B S E R V A T O R Y   &   N O N - C R I T I C A L
 / ___/  _   _   _   _   _   _   _   _   _   _   _   _   _
( (___  / \ / \ / \ / \ / \ / \ / \ / \ / \ / \ / \ / \ / )
 \____\/_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/ \_/
"""

DENIED_ART = r"""
  ____   E N T R Y   D E N I E D
 / __ \  
| |  | |  ACCESS DENIED: model predicted 0 (no access)
| |  | |  
| |__| |  
 \____/   
"""

FOOTER = "\n------------------\n"

# ---------- helpers ----------
def read_params_csv(path):
    with open(path, newline='') as f:
        reader = csv.DictReader(f)
        if reader.fieldnames is None:
            raise ValueError("params.csv is empty or invalid.")
        expected = [f"T{i}" for i in range(EXPECTED_LENGTH + 1)]
        header = reader.fieldnames
        # try to find T0..T16 sequence within header
        try:
            start = header.index("T0")
            for i in range(EXPECTED_LENGTH + 1):
                if header[start + i] != expected[i]:
                    raise ValueError
        except Exception:
            if header[:EXPECTED_LENGTH+1] != expected:
                raise ValueError(f"params.csv must have header containing: {expected}")
        row = next(reader, None)
        if row is None:
            raise ValueError("params.csv has header but no data row.")
        params = []
        for i in range(EXPECTED_LENGTH + 1):
            key = f"T{i}"
            try:
                params.append(float(row[key]))
            except Exception as e:
                raise ValueError(f"Unable to parse parameter {key}: {e}")
        return params

def sigmoid(z):
    # numerically stable sigmoid
    if z >= 0:
        ez = math.exp(-z)
        return 1.0 / (1.0 + ez)
    else:
        ez = math.exp(z)
        return ez / (1.0 + ez)

def parse_vector_input(s):
    s = s.strip()
    if s.startswith("[") and s.endswith("]"):
        s = s[1:-1]
    if "," in s:
        parts = [p.strip() for p in s.split(",")]
    else:
        parts = [p for p in s.split()]
    if len(parts) != EXPECTED_LENGTH:
        raise ValueError(f"Expected {EXPECTED_LENGTH} integers, got {len(parts)}")
    vec = []
    for p in parts:
        try:
            v = int(p)
        except:
            raise ValueError(f"Could not parse integer from '{p}'")
        if v < -16 or v > 16:
            raise ValueError(f"Value {v} out of allowed range [-16,16]")
        vec.append(v)
    return vec

def canonicalize(vec):
    return ",".join(str(int(x)) for x in vec)

def salted_digest_hex(salt_hex, canonical_str):
    h = hashlib.sha256()
    h.update(bytes.fromhex(salt_hex))
    h.update(canonical_str.encode())
    return h.hexdigest()

def show_health_portal():
    print(HEALTH_ART)
    print("-" * 60)
    print("Welcome, Administrator.")
    print("Live telemetry (sim):")
    print("Patient | HR  | SpO2 | Status")
    print(f"1001    | {random.randint(75,100)} | {random.randint(98,100)}%  | STABLE")
    print(f"1002    | {random.randint(75,100)} | {random.randint(97,100)}%  | MONITOR")
    print(f"1003    | {random.randint(75,100)} | {random.randint(85,95)}%  | CRITICAL")
    print("-" * 60)


def show_noncritical_menu():
    print(NONCRIT_ART)
    print("Accessing non-critical subsystems:")
    print("- Observatory: telescope pointing & live sky map")
    print("- Environmental Controls: cabin lighting, ambient music")
    print("- Tourist Console: city views & postcards")
    print("\n[Observatory] Current target: Kepler-186f")
    print("Telescope Azimuth: 132.4°  Elevation: 54.2°")
    print("\n[Environmental] Lighting: Normal  | Temperature: 22°C | Music: 'SpaceLounge'")
    print("\n[Tourist Console] Featured: 'Aurora of Rigel' ")
    print("-" * 60)

def show_access_denied():
    print(DENIED_ART)

# ---------- Entry flow ----------
def slow_print(msg, delay=0.02):
    for ch in msg:
        print(ch, end='', flush=True)
        time.sleep(delay)
    print()

def main():
    slow_print(BANNER, 0.003)
    print(textwrap.dedent("""
    Welcome to the portal.
    Provide a 16-integer ACCESS CODE (each value in [-16,16]) to evaluate.
    """))

    if len(sys.argv) < 2:
        print("Usage: python3 portal.py model.csv [optional_vector]")
        sys.exit(1)

    params_csv = sys.argv[1]
    vector_arg = sys.argv[2] if len(sys.argv) >= 3 else None

    try:
        params = read_params_csv(params_csv)
    except Exception as e:
        print("Error loading params file:", e)
        sys.exit(2)

    # Input vector
    if vector_arg:
        try:
            vec = parse_vector_input(vector_arg)
        except Exception as e:
            print("Input error:", e)
            sys.exit(3)
    else:
        try:
            raw = input("Enter 16 comma-separated integers in [-16,16]: ").strip()
        except EOFError:
            print("No input provided.")
            sys.exit(4)
        try:
            vec = parse_vector_input(raw)
        except Exception as e:
            print("Input error:", e)
            sys.exit(5)

    # Evaluate model
    intercept = params[0]
    coefs = params[1:]
    logit = intercept + sum(c * x for c, x in zip(coefs, vec))
    prob = sigmoid(logit)
    pred = 1 if prob >= 0.5 else 0

    print("\n" + "-"*60)
    # print("MODEL OUTPUT")
    # print(f"Logit: {logit:.6f}")
    # print(f"Probability: {prob:.6f}")
    # print(f"ACCESS (model prediction): {pred}")
    # print("-"*60)

    # Digest check
    canonical = canonicalize(vec)
    digest = salted_digest_hex(SALT_HEX, canonical)

    # Decision logic:
    # - pred == 1 and digest matches -> ADMIN (health)
    # - pred == 1 and digest mismatches -> NON-ADMIN (non-critical systems)
    # - pred == 0 -> Access denied
    if pred == 1 and digest == EMBED_DIGEST:
        slow_print("\n[VERIFICATION] Salted digest matched. Admin privileges confirmed.\n", 0.005)
        while(1):
            print("[COMMANDS] critical | non-critical | exit")
            cmd = input("Enter command: ")
            if cmd == "exit":
                break
            elif cmd == "critical":
                show_health_portal()
                print("Flag: ZenseCTF{"+salted_digest_hex("6239a8e504dfc59f9691ff98c25a2e82",canonical)+"}")
            elif cmd == "non-critical":
                show_noncritical_menu()
            else:
                print("Unknown command.")
            print("-" * 60)
    elif pred == 1 and digest != EMBED_DIGEST:
        slow_print("\n[NOTICE] Model granted access, but you are not the admin. Non-critical systems unlocked.\n", 0.005)
        while(1):
            print("[COMMANDS] non-critical | exit")
            cmd = input("Enter command: ")
            if cmd == "exit":
                break
            elif cmd == "non-critical":
                show_noncritical_menu()
            else:
                print("Unknown command.")
            print("-" * 60)
    else:
        slow_print("\n[NOTICE] Model denies access. No systems available.\n", 0.005)
        show_access_denied()

    print(FOOTER)

if __name__ == "__main__":
    main()
