#!/usr/bin/env python3
import sys
import numpy as np
import pandas as pd
from scipy.optimize import minimize

def sigmoid(z):
    # numerically stable sigmoid
    z = np.clip(z, -709, 709)
    return 1.0 / (1.0 + np.exp(-z))

def objective_and_grad(p, X, y, lam):
    b = p[0]
    w = p[1:]
    n = X.shape[0]

    z = b + X.dot(w)            
    s = sigmoid(z)                
    eps = 1e-12
    nll = - (y * np.log(s + eps) + (1 - y) * np.log(1 - s + eps)).sum()
    reg = 0.5 * lam * np.dot(w, w)

    loss = nll + reg
    diff = s - y                   
    grad_b = diff.sum()
    grad_w = X.T.dot(diff) + lam * w

    grad = np.concatenate(([grad_b], grad_w))
    return loss, grad

def train_logreg(infile, outfile, lam=1.0, maxiter=1000, tol=1e-9):
    df = pd.read_csv(infile)
    if df.shape[1] < 2:
        raise SystemExit("Input CSV must contain at least one feature column and one label column.")
    feature_cols = list(df.columns[:-1])
    label_col = df.columns[-1]

    X = df[feature_cols].values.astype(float)
    y = df[label_col].values.astype(int)
    if not set(np.unique(y)).issubset({0,1}):
        raise SystemExit("Labels must be binary 0 or 1.")

    n,k = X.shape
    if k != 16:
        print(f"Warning: found {k} features; expected 16. Proceeding anyway.")

    p0 = np.zeros(k + 1, dtype=float)

    def fun(p):
        loss, grad = objective_and_grad(p, X, y, lam)
        return loss, grad

    res = minimize(fun, p0, method="L-BFGS-B", jac=True,
                   options={"maxiter": maxiter, "ftol": tol, "gtol": 1e-8})

    if not res.success:
        print("Warning: optimizer did not converge:", res.message)

    p_opt = res.x  
    p_rounded = np.round(p_opt.astype(float), 5)

    header = [f"T{i}" for i in range(len(p_rounded))]
    out_df = pd.DataFrame([p_rounded], columns=header)
    out_df.to_csv(outfile, index=False)
    print(f"Trained logistic regression (lambda={lam}). Wrote params to {outfile}")
    return res

def main():
    if len(sys.argv) != 3:
        print("Usage: python3 train_cleaned.py creds.csv params_out.csv")
        sys.exit(1)
    infile = sys.argv[1]
    outfile = sys.argv[2]
    train_logreg(infile, outfile, lam=1.0)

if __name__ == "__main__":
    main()
