You are too ahead of the crowd.
